# ─────────────────────────────────────────────
#  DataGrid — Instalador + Registro de protocolo
#  HistoryGamesProductions
# ─────────────────────────────────────────────

# Verificar versión mínima de Windows
$currentWindowsVersion = (Get-WmiObject Win32_OperatingSystem).Version -as [Version]
$minWindowsVersion = "10.0.19041" -as [Version]
if ($currentWindowsVersion -And $currentWindowsVersion -lt $minWindowsVersion) {
    throw "Para instalar DataGrid necesitas Windows 10 versión 2004 (19041) o superior."
}

# ── 1. INSTALAR LA APP ──
Write-Host "Instalando DataGrid..."
$currentDir = Get-Location
$msixPath = ($currentDir.Path + "\" + "DataGrid.sideload.msix")
$installProc = Start-Process -FilePath "utils\pwainstaller.exe" -ArgumentList "`"$msixPath`"" -NoNewWindow -PassThru
$handle = $installProc.Handle
$exitedNormally = $installProc.WaitForExit(10000)

if ($installProc.ExitCode -ne 0) {
    Write-Error ("Instalación fallida, código de salida: " + $installProc.ExitCode)
    Read-Host -Prompt "Presiona Enter para salir"
    exit 1
}

# ── 2. REGISTRAR PROTOCOLO datagrid:// ──
Write-Host "Registrando protocolo datagrid://..."

$appId = "HistoGamers.DataGrid_1ttt64gpxas04!App"

# El comando que ejecuta el protocolo: abre la app por su AppId
$launchCmd = "powershell.exe -WindowStyle Hidden -Command `"Start-Process 'shell:AppsFolder\$appId'`""

# Crear entradas en el registro
$regBase = "HKCU:\Software\Classes\datagrid"

New-Item -Path $regBase -Force | Out-Null
Set-ItemProperty -Path $regBase -Name "(Default)" -Value "URL:DataGrid Protocol"
New-ItemProperty -Path $regBase -Name "URL Protocol" -Value "" -PropertyType String -Force | Out-Null

New-Item -Path "$regBase\shell" -Force | Out-Null
New-Item -Path "$regBase\shell\open" -Force | Out-Null
New-Item -Path "$regBase\shell\open\command" -Force | Out-Null
Set-ItemProperty -Path "$regBase\shell\open\command" -Name "(Default)" -Value $launchCmd

Write-Host "Protocolo datagrid:// registrado correctamente."

# ── 3. ABRIR LA APP ──
Write-Host "Abriendo DataGrid..."
$app = Get-StartApps "DataGrid"

if ($app -is [array]) { $app = $app[-1] }

if ($app) {
    Start-Process ("shell:AppsFolder\" + $app.AppId)
} else {
    Write-Host "DataGrid instalado. Búscalo en el menú Inicio."
}
